from django.contrib import admin

from .models import diseasePrediction,DesandPrec
# Register your models here.

admin.site.register(diseasePrediction)
admin.site.register(DesandPrec)